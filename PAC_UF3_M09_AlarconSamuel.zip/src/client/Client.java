package client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	// Definimos como constantes el host, el puerto y el cliente.

	private final String Host = "localhost";
	private final int Port = 9876;
	private final Socket socket; // Socket necesario para cliente

	// Creamos el constructor y lo configuramos para que arroje exception en caso de
	// ser necesaria.
	public Client() throws IOException {
		socket = new Socket(Host, Port);
	}

	public void conectarCliente() {

		// Instanciamos objeto scanner para registrar datos que entren por teclado.

		Scanner scdatos = new Scanner(System.in);

		// En esta primera parte recogemos datos de server e interactuamos con el
		// cliente.
		try {

			DataInputStream entrada = new DataInputStream(socket.getInputStream());
			DataOutputStream salida = new DataOutputStream(socket.getOutputStream());
			System.out.println(entrada.readUTF());
			salida.writeUTF(scdatos.nextLine());
			System.out.println(entrada.readUTF());

			// Tareas

			int regTareas = Integer.parseInt(scdatos.nextLine());
			salida.writeInt(regTareas);

			/*
			 * bucle que se repite por cada tarea que introduzcamos. Pregunta por la tarea,
			 * su descripción, el estado y lo envía.
			 */

			for (int i = 1; i <= regTareas; i++) {
				System.out.println(entrada.readUTF());
				System.out.println(entrada.readUTF());
				salida.writeUTF(scdatos.nextLine());
				System.out.println(entrada.readUTF());
				salida.writeUTF(scdatos.nextLine());
			}

			// Muestra el listado de las tareas
			System.out.println(entrada.readUTF());

			for (int i = 0; i < regTareas; i++) {
				System.out.println(entrada.readUTF());
			}
			salida.close();
			entrada.close();
			scdatos.close();
			socket.close();

		} catch (IOException ex) {
			System.err.println("No se ha podido establecer la conexión.");

			/*
			 * Dudaba en esta parte si incluir un Finally o no, pero al final consulté
			 * "https://www.arquitecturajava.com/java-finally-y-el-cierre-de-recursos/" y
			 * decidí incluirlo.
			 */

		} finally {
			System.out.println("Gracias por utilizar nuestros servicios.");
		}
	}
}