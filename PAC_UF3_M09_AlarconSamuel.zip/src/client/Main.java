package client;

import java.io.IOException;

//Creamos el objeto cliente y nos conectamos a él. Adicionalmente, ponemos un mensaje para confirmar que el cliente se está iniciando.

public class Main {
	public static void main(String[] args) throws IOException {
		Client client = new Client();
		System.out.println("Iniciando cliente...");
		client.conectarCliente();
	}
}