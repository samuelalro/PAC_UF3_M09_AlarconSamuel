package server;

import java.io.IOException;

//Creamos el objeto server y nos conectamos a él. Adicionalmente, ponemos un mensaje para confirmar que el server se está iniciando.

public class Main {
	public static void main(String[] args) throws IOException {

		Server server = new Server();
		System.out.println("Iniciando server...");
		server.connect();
		System.out.println("Conectado.");
	}
}
