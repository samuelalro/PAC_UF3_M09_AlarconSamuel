package server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	// Puerto, objeto para levantar el server y objeto para conexión con el cliente.
	private final int Port = 9876;
	private ServerSocket server;
	private Socket socket;

	// Constructor para poder iniciar server y cliente.
	public Server() throws IOException {
		server = new ServerSocket(Port);
		socket = new Socket();
	}

//Establecemos desde el servidor, la conexión con el cliente
	public void connect() throws IOException {
		while (true) {
			socket = server.accept();

			DataInputStream entrada = new DataInputStream(socket.getInputStream());
			DataOutputStream salida = new DataOutputStream(socket.getOutputStream());

			salida.writeUTF("Bienvenido. Diga su nombre:");
			System.out.println(entrada.readUTF());
			salida.writeUTF("Cantidad de tareas a realizar:");

			// Guardamos tareas y creamos Array.
			int regTareas = entrada.readInt();
			System.out.println(regTareas);
			Tarea[] tareas = new Tarea[regTareas];

			// Guardamos la información recibida relativa a las tareas, tanto la descripción
			// como el estado en el que se encuentra.
			for (int i = 1; i <= regTareas; i++) {
				Tarea trabajo = new Tarea();
				salida.writeUTF("Se va a solicitar breve resumen de la tarea:" + i);
				salida.writeUTF("Describa la tarea: ");
				trabajo.setDescription(entrada.readUTF());
				salida.writeUTF("Introduzca el estado de la tarea: ");
				trabajo.setEstado(entrada.readUTF());
				tareas[i - 1] = trabajo;
			}

			/*
			 * Mensaje arrojado una vez se envia el listado de tareas. Configurado para que
			 * aparezca tanto la tarea descrita, como el estado, ambos datos quehemos
			 * guardado previamente.
			 */
			salida.writeUTF("Se va a mostrar listado de tareas.\nListado de tareas: ");
			for (int i = 0; i < regTareas; i++) {
				salida.writeUTF("La tarea: " + tareas[i].getDescription() + ". " + "Estado:  " + tareas[i].getEstado());
			}
			socket.close();
		}
	}
}