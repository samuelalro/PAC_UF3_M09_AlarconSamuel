package server;

public class Tarea {
	// Creamos atributos solicitados en el trabajo, así como el constructor.
	private String estado;
	private String description;

	public Tarea() {
		estado = "";
		description = "";
	}
	// Generamos automáticamente los getters y los setters.

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	// toString para que arroje el mensaje que queremos con respecto a la info de
	// las tareas.
	@Override
	public String toString() {
		return "La tarea{" + "descripción='" + description + "Estado:='" + estado + "}";
	}
}
